// Write a JavaScript function to compute the sum of an array of integers.
