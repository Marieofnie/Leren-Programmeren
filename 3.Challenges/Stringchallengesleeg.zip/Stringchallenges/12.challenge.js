// Write a Javascript function to return wether a value is divisible by a certain number

// 	isDivisible(333,7)
// 	=> false
