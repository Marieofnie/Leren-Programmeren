// given ["Ellen","bert","Bart","zaki","Sandra","Soroush"]
//     remove all the names that do not start with a capital
