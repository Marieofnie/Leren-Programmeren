// 1- Write a JavaScript function to check whether a string is blank or not.
// 	console.log(is_Blank(''));
// 		true
// 	console.log(is_Blank('abc'));
// 		false

function is_blank(string) {
  return string.length === 0;
}
console.log(is_blank("pij"));
