// Write a JavaScript function to check if a certain word is a Palindrome.
