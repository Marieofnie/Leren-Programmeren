// Write a Javascript function that calculate the distance between two coordinates.
// 	getDistance([20,100],[50,800])
