// Write a JavaScript function that returns an array with generated  Multiplication Table of a given number (max. 1000 iterations)
// 	var result =  generateMultiplicationTable(5);
// 	console.log(result);
