// Write a JavaScript function to get a random item from an array.
