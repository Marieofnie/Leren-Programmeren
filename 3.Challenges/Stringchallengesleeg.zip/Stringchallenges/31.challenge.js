// Write a JavaScript program to find the most frequent item of an array.
