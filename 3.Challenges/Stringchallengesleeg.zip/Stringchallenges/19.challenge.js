// Write a JavaScript function to remove a specific element from an array
//     const myNames = ["John","Cindy","Omer","Barbie","Barbie"];
//     removeSpecificelement(myNames,"Barbie");
