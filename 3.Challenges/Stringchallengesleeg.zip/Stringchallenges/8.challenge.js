// - Write a JavaScript function to test whether a string ends with a specified string.
// 	console.log(endsWith('JS string exercises', 'exercises'));
// 		true
function endsWith(string, word) {
  return string.endsWith(word);
}
console.log(endsWith("JS string exercises", "exercises"));
