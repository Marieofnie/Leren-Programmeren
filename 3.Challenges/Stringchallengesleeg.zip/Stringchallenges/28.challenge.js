// given [2,1,6,4]
//     calc avg
//     calc sum    (reduce)
