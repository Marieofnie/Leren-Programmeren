// Write a JavaScript function to generate an array with the first X Fibonacci numbers.
