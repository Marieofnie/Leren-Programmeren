// given [2,1,6,4]
//     expected => [8,1,216,64] => the power N
//     nthPower([2,1,6,4],16)
