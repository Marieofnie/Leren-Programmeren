// Write a function to remove all strings with less than X characters from an array of strings
