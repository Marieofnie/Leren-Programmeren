// Write a JavaScript function that returns array elements larger than a number

//     given:
//         var numbers = [5,2,20,60,45];
//         var toCheck = 6;

//     returned array:
//         [20,60,45]
