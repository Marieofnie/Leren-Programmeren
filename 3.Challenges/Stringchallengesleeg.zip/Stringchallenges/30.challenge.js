// Write a Javascript function to find how many times a certain number occurs in that array.
