// Write a Javascript function that return an array with even numbers between a range
// 	getEvenNumbersInRange(56,1211)
