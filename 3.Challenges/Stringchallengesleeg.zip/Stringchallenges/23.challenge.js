// Write a Javascript function to generate a random color in format rgb(0,0,0);
