// Write a JavaScript function to merge two arrays and removes all duplicates elements.

//     FROM HERE NO FOR LOOPS ALLOWED
