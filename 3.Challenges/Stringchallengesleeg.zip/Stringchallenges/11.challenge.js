// extension of first challenge:
// 	Every time a value in the array is divisible by 20 add an (asterisk)* to it
