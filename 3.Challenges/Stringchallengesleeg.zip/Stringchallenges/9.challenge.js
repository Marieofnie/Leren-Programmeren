// - Write a JavaScript function to get unique guid (an acronym for 'Globally Unique Identifier?) of the
// specified length, or 32 by default.
// 	console.log(guid());
// 		"hRYilcoV7ajokxsYFl1dba41AyE0rUQR"
// 	console.log(guid(15));
// 		"b7pwBqrZwqaDrex"
function guid(i) {
  return;
}
console.log(guid());
console.log(guid(15));
